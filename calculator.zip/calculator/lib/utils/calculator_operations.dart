/// Utility class for calculator operations and parsing
class CalculatorOperations {
  /// Performs basic arithmetic operations
  static double add(double a, double b) => a + b;
  
  static double subtract(double a, double b) => a - b;
  
  static double multiply(double a, double b) => a * b;
  
  static double divide(double a, double b) {
    if (b == 0) {
      throw ArgumentError('Division by zero');
    }
    return a / b;
  }
  
  static double percentage(double value) => value / 100;
  
  static double toggleSign(double value) => -value;

  /// Evaluates a mathematical expression using BODMAS rules
  static double evaluateExpression(String expression) {
    try {
      // Remove spaces and validate
      expression = expression.replaceAll(' ', '');
      if (expression.isEmpty) return 0;

      // Handle unary minus at start
      if (expression.startsWith('-')) {
        expression = '0' + expression;
      }

      // Replace × and ÷ with * and /
      expression = expression.replaceAll('×', '*');
      expression = expression.replaceAll('÷', '/');

      // Convert percentage signs
      expression = _convertPercentages(expression);

      // Use a simple recursive descent parser for proper order of operations
      return _evaluate(_tokenize(expression));
    } catch (e) {
      throw ArgumentError('Invalid expression: $e');
    }
  }

  /// Tokenizes the expression into numbers and operators
  static List<String> _tokenize(String expression) {
    List<String> tokens = [];
    String currentNumber = '';

    for (int i = 0; i < expression.length; i++) {
      String char = expression[i];

      if (char == '.' || (char.codeUnitAt(0) >= 48 && char.codeUnitAt(0) <= 57)) {
        // Digit or decimal point
        currentNumber += char;
      } else {
        // Operator
        if (currentNumber.isNotEmpty) {
          tokens.add(currentNumber);
          currentNumber = '';
        }
        tokens.add(char);
      }
    }

    if (currentNumber.isNotEmpty) {
      tokens.add(currentNumber);
    }

    return tokens;
  }

  /// Converts percentage expressions (e.g., "50%" to "0.5")
  static String _convertPercentages(String expression) {
    // Simple approach: replace patterns like "50%" with "0.5"
    // This is a simplified version - a full implementation would be more complex
    return expression.replaceAllMapped(
      RegExp(r'(\d+\.?\d*)%'),
      (match) => (double.parse(match.group(1)!) / 100).toString(),
    );
  }

  /// Evaluates tokens respecting operator precedence (BODMAS)
  static double _evaluate(List<String> tokens) {
    if (tokens.isEmpty) return 0;
    if (tokens.length == 1) return double.parse(tokens[0]);

    // Convert tokens to list of numbers and operators
    List<dynamic> processed = [];
    for (String token in tokens) {
      if (token == '+' || token == '-' || token == '*' || token == '/') {
        processed.add(token);
      } else {
        processed.add(double.parse(token));
      }
    }

    // Handle multiplication and division first (left to right)
    while (true) {
      int index = -1;
      for (int i = 0; i < processed.length; i++) {
        if (processed[i] == '*' || processed[i] == '/') {
          index = i;
          break;
        }
      }
      
      if (index == -1) break;

      double left = processed[index - 1] as double;
      double right = processed[index + 1] as double;
      double result = processed[index] == '*'
          ? multiply(left, right)
          : divide(left, right);
      
      processed.removeRange(index - 1, index + 2);
      processed.insert(index - 1, result);
    }

    // Handle addition and subtraction (left to right)
    double result = processed[0] as double;
    for (int i = 1; i < processed.length - 1; i += 2) {
      double operand = processed[i + 1] as double;
      if (processed[i] == '+') {
        result = add(result, operand);
      } else if (processed[i] == '-') {
        result = subtract(result, operand);
      }
    }

    return result;
  }

  /// Formats a number for display, removing unnecessary decimal places
  static String formatResult(double value) {
    // Check if it's a whole number
    if (value % 1 == 0) {
      return value.toInt().toString();
    }
    
    // Limit decimal places to avoid floating point errors
    String result = value.toStringAsFixed(10);
    // Remove trailing zeros
    result = result.replaceAll(RegExp(r'0*$'), '');
    result = result.replaceAll(RegExp(r'\.$'), '');
    
    return result;
  }

  /// Validates if a string can be a valid number
  static bool isValidNumber(String value) {
    if (value.isEmpty) return false;
    try {
      double.parse(value);
      return true;
    } catch (e) {
      return false;
    }
  }
}
