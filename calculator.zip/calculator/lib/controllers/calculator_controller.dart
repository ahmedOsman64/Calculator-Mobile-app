import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../models/calculator_model.dart';
import '../utils/calculator_operations.dart';

/// Controller class managing calculator state and operations
class CalculatorController extends ChangeNotifier {
  CalculatorState _state = const CalculatorState();
  List<CalculationHistory> _history = [];
  bool _isDarkTheme = true;

  CalculatorState get state => _state;
  List<CalculationHistory> get history => _history;
  bool get isDarkTheme => _isDarkTheme;

  /// Haptic feedback helper
  Future<void> _hapticFeedback() async {
    await HapticFeedback.lightImpact();
  }

  /// Handle number button press
  void onNumberPressed(String number) {
    _hapticFeedback();
    
    if (_state.errorMessage != null) {
      clearAll();
      _state = _state.copyWith(
        display: number,
        shouldResetDisplay: false,
        clearError: true,
      );
    } else if (_state.shouldResetDisplay) {
      _state = _state.copyWith(
        display: number,
        shouldResetDisplay: false,
      );
    } else {
      String newDisplay = _state.display == '0' ? number : _state.display + number;
      _state = _state.copyWith(display: newDisplay);
    }
    
    notifyListeners();
  }

  /// Handle operator button press
  void onOperatorPressed(String operator) {
    _hapticFeedback();
    
    if (_state.errorMessage != null) {
      return;
    }

    String currentDisplay = _state.display;
    String currentExpression = _state.expression;

    // Build expression: if expression ends with operator, replace it
    // Otherwise append current display to expression
    if (currentExpression.isNotEmpty && currentExpression.endsWith(' ')) {
      // Expression ends with operator, remove the last operator and replace
      String trimmed = currentExpression.trim();
      int lastSpaceIndex = trimmed.lastIndexOf(' ');
      if (lastSpaceIndex >= 0) {
        currentExpression = trimmed.substring(0, lastSpaceIndex + 1);
      } else {
        currentExpression = '';
      }
      currentExpression = currentExpression.isEmpty 
          ? currentDisplay 
          : '$currentExpression $currentDisplay';
    } else {
      // Append current display to expression if not empty
      currentExpression = currentExpression.isEmpty 
          ? currentDisplay 
          : '$currentExpression $currentDisplay';
    }

    // Map operator symbols
    String operatorSymbol = operator;
    if (operator == '×') operatorSymbol = '×';
    if (operator == '÷') operatorSymbol = '÷';

    _state = _state.copyWith(
      display: currentDisplay,
      expression: '$currentExpression $operatorSymbol ',
      shouldResetDisplay: true,
    );
    
    notifyListeners();
  }

  /// Handle decimal point button
  void onDecimalPressed() {
    _hapticFeedback();
    
    if (_state.errorMessage != null) {
      clearAll();
      _state = _state.copyWith(display: '0.', shouldResetDisplay: false, clearError: true);
    } else if (_state.shouldResetDisplay) {
      _state = _state.copyWith(display: '0.', shouldResetDisplay: false);
    } else if (!_state.display.contains('.')) {
      _state = _state.copyWith(display: _state.display + '.');
    }
    
    notifyListeners();
  }

  /// Handle percentage button
  void onPercentagePressed() {
    _hapticFeedback();
    
    if (_state.errorMessage != null) return;

    try {
      double value = double.parse(_state.display);
      double result = CalculatorOperations.percentage(value);
      _state = _state.copyWith(
        display: CalculatorOperations.formatResult(result),
        shouldResetDisplay: false,
      );
    } catch (e) {
      _state = _state.copyWith(errorMessage: 'Invalid percentage');
    }
    
    notifyListeners();
  }

  /// Handle plus/minus toggle button
  void onToggleSign() {
    _hapticFeedback();
    
    if (_state.errorMessage != null) return;

    try {
      double value = double.parse(_state.display);
      double result = CalculatorOperations.toggleSign(value);
      _state = _state.copyWith(
        display: CalculatorOperations.formatResult(result),
        shouldResetDisplay: false,
      );
    } catch (e) {
      _state = _state.copyWith(errorMessage: 'Invalid number');
    }
    
    notifyListeners();
  }

  /// Handle equals button
  void onEqualsPressed() {
    _hapticFeedback();
    
    if (_state.errorMessage != null) return;

    if (_state.expression.isEmpty) {
      // No operation in progress, just display current value
      return;
    }

    try {
      String fullExpression = _state.expression + _state.display;
      double result = CalculatorOperations.evaluateExpression(fullExpression);
      String formattedResult = CalculatorOperations.formatResult(result);
      
      _addToHistory(fullExpression, formattedResult);
      
      _state = _state.copyWith(
        display: formattedResult,
        expression: '',
        shouldResetDisplay: true,
      );
    } catch (e) {
      _state = _state.copyWith(
        errorMessage: 'Error: ${e.toString()}',
        expression: '',
      );
    }
    
    notifyListeners();
  }

  /// Handle clear button (C)
  void clear() {
    _hapticFeedback();
    
    _state = _state.copyWith(
      display: '0',
      shouldResetDisplay: false,
      clearError: true,
    );
    
    notifyListeners();
  }

  /// Handle all clear button (AC)
  void clearAll() {
    _hapticFeedback();
    
    _state = const CalculatorState();
    notifyListeners();
  }

  /// Add calculation to history
  void _addToHistory(String expression, String result) {
    _history.insert(0, CalculationHistory(
      expression: expression,
      result: result,
    ));
    
    // Limit history to 50 entries
    if (_history.length > 50) {
      _history = _history.sublist(0, 50);
    }
  }

  /// Clear calculation history
  void clearHistory() {
    _history.clear();
    notifyListeners();
  }

  /// Toggle theme
  void toggleTheme() {
    _isDarkTheme = !_isDarkTheme;
    notifyListeners();
  }
}
