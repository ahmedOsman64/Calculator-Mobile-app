import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';
import 'controllers/calculator_controller.dart';
import 'widgets/display_widget.dart';
import 'widgets/calculator_grid.dart';
import 'widgets/history_widget.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  
  // Set preferred orientations
  SystemChrome.setPreferredOrientations([
    DeviceOrientation.portraitUp,
    DeviceOrientation.portraitDown,
  ]);
  
  runApp(const CalculatorApp());
}

class CalculatorApp extends StatelessWidget {
  const CalculatorApp({super.key});

  @override
  Widget build(BuildContext context) {
    return ChangeNotifierProvider(
      create: (_) => CalculatorController(),
      child: Consumer<CalculatorController>(
        builder: (context, controller, _) {
          return MaterialApp(
            title: 'Calculator',
            debugShowCheckedModeBanner: false,
            theme: ThemeData(
              brightness: Brightness.light,
              colorScheme: ColorScheme.light(
                primary: const Color(0xFF1976D2),
                secondary: const Color(0xFF4CAF50),
                background: const Color(0xFFF5F5F5),
                surface: Colors.white,
              ),
              scaffoldBackgroundColor: const Color(0xFFF5F5F5),
              useMaterial3: true,
            ),
            darkTheme: ThemeData(
              brightness: Brightness.dark,
              colorScheme: ColorScheme.dark(
                primary: const Color(0xFF007ACC),
                secondary: const Color(0xFF00AA44),
                background: const Color(0xFF121212),
                surface: const Color(0xFF1E1E1E),
              ),
              scaffoldBackgroundColor: const Color(0xFF121212),
              useMaterial3: true,
            ),
            themeMode: controller.isDarkTheme 
                ? ThemeMode.dark 
                : ThemeMode.light,
            home: const CalculatorScreen(),
          );
        },
      ),
    );
  }
}

class CalculatorScreen extends StatefulWidget {
  const CalculatorScreen({super.key});

  @override
  State<CalculatorScreen> createState() => _CalculatorScreenState();
}

class _CalculatorScreenState extends State<CalculatorScreen> {
  bool _showHistory = false;

  @override
  Widget build(BuildContext context) {
    final controller = Provider.of<CalculatorController>(context);
    
    return Scaffold(
      body: SafeArea(
        child: Column(
          children: [
            // App bar with theme toggle and history toggle
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 8.0),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  const Text(
                    'Calculator',
                    style: TextStyle(
                      fontSize: 24,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  Row(
                    children: [
                      IconButton(
                        icon: Icon(_showHistory ? Icons.calculate : Icons.history),
                        onPressed: () {
                          setState(() {
                            _showHistory = !_showHistory;
                          });
                        },
                        tooltip: _showHistory ? 'Show Calculator' : 'Show History',
                      ),
                      IconButton(
                        icon: Icon(
                          controller.isDarkTheme
                              ? Icons.light_mode
                              : Icons.dark_mode,
                        ),
                        onPressed: () => controller.toggleTheme(),
                        tooltip: 'Toggle theme',
                      ),
                    ],
                  ),
                ],
              ),
            ),
            
            if (_showHistory)
              // History view
              Expanded(
                child: HistoryWidget(
                  history: controller.history,
                  onClear: () => controller.clearHistory(),
                ),
              )
            else ...[
              // Display widget
              DisplayWidget(state: controller.state),
              
              // Calculator grid
              Expanded(
                child: CalculatorGrid(controller: controller),
              ),
            ],
          ],
        ),
      ),
    );
  }
}