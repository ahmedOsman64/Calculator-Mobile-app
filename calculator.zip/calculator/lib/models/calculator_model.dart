/// Model class representing calculator state
class CalculatorState {
  final String display;
  final String expression;
  final bool shouldResetDisplay;
  final String? errorMessage;

  const CalculatorState({
    this.display = '0',
    this.expression = '',
    this.shouldResetDisplay = false,
    this.errorMessage,
  });

  CalculatorState copyWith({
    String? display,
    String? expression,
    bool? shouldResetDisplay,
    String? errorMessage,
    bool clearError = false,
  }) {
    return CalculatorState(
      display: display ?? this.display,
      expression: expression ?? this.expression,
      shouldResetDisplay: shouldResetDisplay ?? this.shouldResetDisplay,
      errorMessage: clearError ? null : (errorMessage ?? this.errorMessage),
    );
  }
}

/// Model representing a calculation history entry
class CalculationHistory {
  final String expression;
  final String result;
  final DateTime timestamp;

  CalculationHistory({
    required this.expression,
    required this.result,
    DateTime? timestamp,
  }) : timestamp = timestamp ?? DateTime.now();

  @override
  String toString() => '$expression = $result';
}
