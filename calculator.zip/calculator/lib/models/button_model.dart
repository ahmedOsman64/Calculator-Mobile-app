/// Model class representing a calculator button
class CalculatorButton {
  final String label;
  final ButtonType type;
  final ButtonCategory category;

  const CalculatorButton({
    required this.label,
    required this.type,
    required this.category,
  });
}

/// Enum representing different button types
enum ButtonType {
  number,
  operator,
  function,
  equals,
  clear,
  clearAll,
}

/// Enum representing button categories for styling
enum ButtonCategory {
  number,      // 0-9, .
  operation,   // +, -, ×, ÷
  function,    // %, ±
  equals,      // =
  clear,       // C, AC
}
