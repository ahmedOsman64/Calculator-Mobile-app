import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../models/button_model.dart';

/// Custom button widget for calculator
class CalculatorButton extends StatefulWidget {
  final String label;
  final VoidCallback onPressed;
  final ButtonCategory category;

  const CalculatorButton({
    super.key,
    required this.label,
    required this.onPressed,
    required this.category,
  });

  @override
  State<CalculatorButton> createState() => _CalculatorButtonState();
}

class _CalculatorButtonState extends State<CalculatorButton>
    with SingleTickerProviderStateMixin {
  bool _isPressed = false;
  late AnimationController _controller;
  late Animation<double> _scaleAnimation;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      duration: const Duration(milliseconds: 100),
      vsync: this,
    );
    _scaleAnimation = Tween<double>(begin: 1.0, end: 0.95).animate(
      CurvedAnimation(parent: _controller, curve: Curves.easeInOut),
    );
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  Color _getButtonColor(BuildContext context) {
    final theme = Theme.of(context);
    final isDark = theme.brightness == Brightness.dark;

    switch (widget.category) {
      case ButtonCategory.number:
        return isDark 
            ? const Color(0xFF505050)
            : const Color(0xFFE0E0E0);
      
      case ButtonCategory.operation:
        return isDark 
            ? const Color(0xFF007ACC)
            : const Color(0xFF1976D2);
      
      case ButtonCategory.function:
        return isDark 
            ? const Color(0xFF6A6A6A)
            : const Color(0xFF9E9E9E);
      
      case ButtonCategory.equals:
        return isDark 
            ? const Color(0xFF00AA44)
            : const Color(0xFF4CAF50);
      
      case ButtonCategory.clear:
        return isDark 
            ? const Color(0xFFD32F2F)
            : const Color(0xFFE53935);
    }
  }

  Color _getTextColor(BuildContext context) {
    final theme = Theme.of(context);
    final isDark = theme.brightness == Brightness.dark;

    switch (widget.category) {
      case ButtonCategory.number:
      case ButtonCategory.clear:
        return isDark ? Colors.white : Colors.black87;
      
      case ButtonCategory.operation:
      case ButtonCategory.function:
      case ButtonCategory.equals:
        return Colors.white;
    }
  }

  void _handleTapDown(TapDownDetails details) {
    setState(() => _isPressed = true);
    _controller.forward();
    HapticFeedback.selectionClick();
  }

  void _handleTapUp(TapUpDetails details) {
    setState(() => _isPressed = false);
    _controller.reverse();
    widget.onPressed();
  }

  void _handleTapCancel() {
    setState(() => _isPressed = false);
    _controller.reverse();
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTapDown: _handleTapDown,
      onTapUp: _handleTapUp,
      onTapCancel: _handleTapCancel,
      child: ScaleTransition(
        scale: _scaleAnimation,
        child: Container(
          decoration: BoxDecoration(
            color: _getButtonColor(context),
            borderRadius: BorderRadius.circular(12),
            boxShadow: _isPressed
                ? []
                : [
                    BoxShadow(
                      color: Colors.black.withOpacity(0.2),
                      blurRadius: 4,
                      offset: const Offset(0, 2),
                    ),
                  ],
          ),
          child: Center(
            child: Text(
              widget.label,
              style: TextStyle(
                fontSize: 28,
                fontWeight: FontWeight.w500,
                color: _getTextColor(context),
                fontFamily: 'monospace',
              ),
            ),
          ),
        ),
      ),
    );
  }
}
