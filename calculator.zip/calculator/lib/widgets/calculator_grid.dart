import 'package:flutter/material.dart';
import '../controllers/calculator_controller.dart';
import '../models/button_model.dart' hide CalculatorButton;
import 'calculator_button.dart';

/// Widget containing the calculator button grid
class CalculatorGrid extends StatelessWidget {
  final CalculatorController controller;

  const CalculatorGrid({super.key, required this.controller});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(16.0),
      child: Column(
        children: [
          // First row: AC, C, %, ÷
          Expanded(
            child: Row(
              children: [
                _buildButton(
                  context,
                  'AC',
                  ButtonCategory.clear,
                  () => controller.clearAll(),
                ),
                _buildButton(
                  context,
                  'C',
                  ButtonCategory.clear,
                  () => controller.clear(),
                ),
                _buildButton(
                  context,
                  '%',
                  ButtonCategory.function,
                  () => controller.onPercentagePressed(),
                ),
                _buildButton(
                  context,
                  '÷',
                  ButtonCategory.operation,
                  () => controller.onOperatorPressed('÷'),
                ),
              ],
            ),
          ),
          const SizedBox(height: 12),

          // Second row: 7, 8, 9, ×
          Expanded(
            child: Row(
              children: [
                _buildButton(
                  context,
                  '7',
                  ButtonCategory.number,
                  () => controller.onNumberPressed('7'),
                ),
                _buildButton(
                  context,
                  '8',
                  ButtonCategory.number,
                  () => controller.onNumberPressed('8'),
                ),
                _buildButton(
                  context,
                  '9',
                  ButtonCategory.number,
                  () => controller.onNumberPressed('9'),
                ),
                _buildButton(
                  context,
                  '×',
                  ButtonCategory.operation,
                  () => controller.onOperatorPressed('×'),
                ),
              ],
            ),
          ),
          const SizedBox(height: 12),

          // Third row: 4, 5, 6, -
          Expanded(
            child: Row(
              children: [
                _buildButton(
                  context,
                  '4',
                  ButtonCategory.number,
                  () => controller.onNumberPressed('4'),
                ),
                _buildButton(
                  context,
                  '5',
                  ButtonCategory.number,
                  () => controller.onNumberPressed('5'),
                ),
                _buildButton(
                  context,
                  '6',
                  ButtonCategory.number,
                  () => controller.onNumberPressed('6'),
                ),
                _buildButton(
                  context,
                  '-',
                  ButtonCategory.operation,
                  () => controller.onOperatorPressed('-'),
                ),
              ],
            ),
          ),
          const SizedBox(height: 12),

          // Fourth row: 1, 2, 3, +
          Expanded(
            child: Row(
              children: [
                _buildButton(
                  context,
                  '1',
                  ButtonCategory.number,
                  () => controller.onNumberPressed('1'),
                ),
                _buildButton(
                  context,
                  '2',
                  ButtonCategory.number,
                  () => controller.onNumberPressed('2'),
                ),
                _buildButton(
                  context,
                  '3',
                  ButtonCategory.number,
                  () => controller.onNumberPressed('3'),
                ),
                _buildButton(
                  context,
                  '+',
                  ButtonCategory.operation,
                  () => controller.onOperatorPressed('+'),
                ),
              ],
            ),
          ),
          const SizedBox(height: 12),

          // Fifth row: ±, 0, ., =
          Expanded(
            child: Row(
              children: [
                _buildButton(
                  context,
                  '±',
                  ButtonCategory.function,
                  () => controller.onToggleSign(),
                ),
                _buildButton(
                  context,
                  '0',
                  ButtonCategory.number,
                  () => controller.onNumberPressed('0'),
                ),
                _buildButton(
                  context,
                  '.',
                  ButtonCategory.number,
                  () => controller.onDecimalPressed(),
                ),
                _buildButton(
                  context,
                  '=',
                  ButtonCategory.equals,
                  () => controller.onEqualsPressed(),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildButton(
    BuildContext context,
    String label,
    ButtonCategory category,
    VoidCallback onPressed,
  ) {
    return Expanded(
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 6.0),
        child: CalculatorButton(
          label: label,
          category: category,
          onPressed: onPressed,
        ),
      ),
    );
  }
}
