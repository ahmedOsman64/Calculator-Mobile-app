import 'package:flutter/material.dart';
import '../models/calculator_model.dart';

/// Widget displaying calculator input and result
class DisplayWidget extends StatelessWidget {
  final CalculatorState state;

  const DisplayWidget({
    super.key,
    required this.state,
  });

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final isDark = theme.brightness == Brightness.dark;
    
    return Container(
      padding: const EdgeInsets.all(24.0),
      decoration: BoxDecoration(
        color: isDark 
            ? const Color(0xFF1E1E1E)
            : const Color(0xFFF5F5F5),
        borderRadius: const BorderRadius.vertical(
          bottom: Radius.circular(30),
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.end,
        children: [
          // Expression display (smaller, secondary text)
          if (state.expression.isNotEmpty)
            Padding(
              padding: const EdgeInsets.only(bottom: 8.0),
              child: Text(
                state.expression,
                style: TextStyle(
                  fontSize: 20,
                  color: isDark 
                      ? Colors.white70
                      : Colors.black54,
                  fontFamily: 'monospace',
                ),
                textAlign: TextAlign.end,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
              ),
            ),
          
          // Main display
          Text(
            state.errorMessage ?? state.display,
            style: TextStyle(
              fontSize: state.display.length > 15 ? 40 : 56,
              fontWeight: FontWeight.w300,
              color: state.errorMessage != null
                  ? Colors.red
                  : (isDark ? Colors.white : Colors.black87),
              fontFamily: 'monospace',
              letterSpacing: 1.2,
            ),
            textAlign: TextAlign.end,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
          ),
        ],
      ),
    );
  }
}
