import 'package:flutter_test/flutter_test.dart';
import 'package:calculator/utils/calculator_operations.dart';

void main() {
  group('CalculatorOperations - Basic Operations', () {
    test('addition', () {
      expect(CalculatorOperations.add(2, 3), equals(5));
      expect(CalculatorOperations.add(10, -5), equals(5));
      expect(CalculatorOperations.add(0, 0), equals(0));
      expect(CalculatorOperations.add(1.5, 2.5), equals(4.0));
    });

    test('subtraction', () {
      expect(CalculatorOperations.subtract(5, 3), equals(2));
      expect(CalculatorOperations.subtract(10, 15), equals(-5));
      expect(CalculatorOperations.subtract(0, 0), equals(0));
      expect(CalculatorOperations.subtract(5.5, 2.5), equals(3.0));
    });

    test('multiplication', () {
      expect(CalculatorOperations.multiply(2, 3), equals(6));
      expect(CalculatorOperations.multiply(10, 0), equals(0));
      expect(CalculatorOperations.multiply(-5, 4), equals(-20));
      expect(CalculatorOperations.multiply(2.5, 4), equals(10.0));
    });

    test('division', () {
      expect(CalculatorOperations.divide(10, 2), equals(5));
      expect(CalculatorOperations.divide(15, 3), equals(5));
      expect(CalculatorOperations.divide(7, 2), equals(3.5));
      expect(CalculatorOperations.divide(-10, 2), equals(-5));
    });

    test('division by zero throws error', () {
      expect(
        () => CalculatorOperations.divide(10, 0),
        throwsA(isA<ArgumentError>()),
      );
    });

    test('percentage', () {
      expect(CalculatorOperations.percentage(50), equals(0.5));
      expect(CalculatorOperations.percentage(100), equals(1.0));
      expect(CalculatorOperations.percentage(25), equals(0.25));
      expect(CalculatorOperations.percentage(0), equals(0));
    });

    test('toggle sign', () {
      expect(CalculatorOperations.toggleSign(5), equals(-5));
      expect(CalculatorOperations.toggleSign(-5), equals(5));
      expect(CalculatorOperations.toggleSign(0), equals(0));
      expect(CalculatorOperations.toggleSign(10.5), equals(-10.5));
    });
  });

  group('CalculatorOperations - Expression Evaluation', () {
    test('simple addition', () {
      expect(
        CalculatorOperations.evaluateExpression('2 + 3'),
        equals(5),
      );
    });

    test('simple subtraction', () {
      expect(
        CalculatorOperations.evaluateExpression('10 - 4'),
        equals(6),
      );
    });

    test('simple multiplication', () {
      expect(
        CalculatorOperations.evaluateExpression('3 × 4'),
        equals(12),
      );
      expect(
        CalculatorOperations.evaluateExpression('3 * 4'),
        equals(12),
      );
    });

    test('simple division', () {
      expect(
        CalculatorOperations.evaluateExpression('10 ÷ 2'),
        equals(5),
      );
      expect(
        CalculatorOperations.evaluateExpression('15 / 3'),
        equals(5),
      );
    });

    test('chain calculations - addition and subtraction', () {
      expect(
        CalculatorOperations.evaluateExpression('2 + 3 - 1'),
        equals(4),
      );
      expect(
        CalculatorOperations.evaluateExpression('10 - 5 + 3'),
        equals(8),
      );
    });

    test('BODMAS - multiplication before addition', () {
      expect(
        CalculatorOperations.evaluateExpression('2 + 3 × 4'),
        equals(14),
      );
      expect(
        CalculatorOperations.evaluateExpression('10 - 2 × 3'),
        equals(4),
      );
    });

    test('BODMAS - division before subtraction', () {
      expect(
        CalculatorOperations.evaluateExpression('10 - 8 ÷ 2'),
        equals(6),
      );
      expect(
        CalculatorOperations.evaluateExpression('20 ÷ 4 - 2'),
        equals(3),
      );
    });

    test('BODMAS - complex expressions', () {
      expect(
        CalculatorOperations.evaluateExpression('2 + 3 × 4 - 1'),
        equals(13),
      );
      expect(
        CalculatorOperations.evaluateExpression('10 ÷ 2 + 3 × 4'),
        equals(17),
      );
    });

    test('decimal numbers', () {
      expect(
        CalculatorOperations.evaluateExpression('2.5 + 3.5'),
        equals(6.0),
      );
      expect(
        CalculatorOperations.evaluateExpression('10.5 × 2'),
        equals(21.0),
      );
    });

    test('negative numbers', () {
      expect(
        CalculatorOperations.evaluateExpression('-5 + 10'),
        equals(5),
      );
      expect(
        CalculatorOperations.evaluateExpression('10 - -5'),
        equals(15),
      );
    });

    test('division by zero in expression throws error', () {
      expect(
        () => CalculatorOperations.evaluateExpression('10 ÷ 0'),
        throwsA(isA<ArgumentError>()),
      );
    });

    test('empty expression returns zero', () {
      expect(CalculatorOperations.evaluateExpression(''), equals(0));
      expect(CalculatorOperations.evaluateExpression('   '), equals(0));
    });

    test('single number', () {
      expect(CalculatorOperations.evaluateExpression('5'), equals(5));
      expect(CalculatorOperations.evaluateExpression('10.5'), equals(10.5));
    });
  });

  group('CalculatorOperations - Formatting', () {
    test('format whole numbers', () {
      expect(CalculatorOperations.formatResult(5.0), equals('5'));
      expect(CalculatorOperations.formatResult(10.0), equals('10'));
      expect(CalculatorOperations.formatResult(0.0), equals('0'));
    });

    test('format decimal numbers', () {
      expect(CalculatorOperations.formatResult(5.5), equals('5.5'));
      expect(CalculatorOperations.formatResult(10.25), equals('10.25'));
    });

    test('format removes trailing zeros', () {
      expect(CalculatorOperations.formatResult(5.5000), equals('5.5'));
      expect(CalculatorOperations.formatResult(10.250000), equals('10.25'));
    });

    test('format handles very small decimals', () {
      String result = CalculatorOperations.formatResult(0.0000001);
      expect(result, isNotEmpty);
    });
  });

  group('CalculatorOperations - Validation', () {
    test('isValidNumber', () {
      expect(CalculatorOperations.isValidNumber('5'), isTrue);
      expect(CalculatorOperations.isValidNumber('10.5'), isTrue);
      expect(CalculatorOperations.isValidNumber('0'), isTrue);
      expect(CalculatorOperations.isValidNumber('-5'), isTrue);
      expect(CalculatorOperations.isValidNumber('abc'), isFalse);
      expect(CalculatorOperations.isValidNumber(''), isFalse);
      expect(CalculatorOperations.isValidNumber('5+3'), isFalse);
    });
  });
}
